#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <signal.h>
#include <sys/time.h>

#include "cyusb.h"

#ifndef __cplusplus
#define inline
#endif

#define WIDTH 1920
#define HEIGHT 1080
#define FULLNUM 8303088



static cyusb_handle *usb_dev = NULL;

/*check stream header*/
static inline bool check_sh(void *sh){
	unsigned int *temp = (unsigned int*)sh;
	if (temp[0] == 0x7c7c7c7c && temp[1] == 0x01010101){
		return true;
	}
	return false;
}

/*check line header*/
static bool check_lineh(void *lineh){
	unsigned int *temp = (unsigned int*)lineh;
	if (temp[0] == 0x7c7c7c7c && temp[1] == 0x02020202){
		return true;
	}
	return false;
}

/*********************************************************************
sign:0x54,0x55
*********************************************************************/
int __camera_control(unsigned char sign,unsigned short addr,unsigned int v){
	unsigned char cmd[10]={0xaa,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xff};
	cmd[1]=sign;
	cmd[2]=addr>>8;
	cmd[3]=addr&0xff;
	cmd[4]=v>>24;
	cmd[5]=(v>>16)&0xff;
	cmd[6]=(v>>8)&0xff;	
	cmd[7]=v&0xff;
	int ret=cyusb_control_transfer(usb_dev,0x20,0xE0,0,0x00,cmd,10,1000);
	if (ret!=10){
		printf("cam_cmd fail,ret=%d\n",ret);
        }
	return ret==10?1:0;
}

int init_usb_dev(){
    int r;

    r = cyusb_open();
    if ( r < 0 ) {
       printf("[!!!!!error!!!!!]Error opening library\n");
       return 0;
    }
    else if ( r == 0 ) {
        printf("[!!!!!error!!!!!]No device found\n");
        return 0;
    }
    if ( r > 1 ) {
        printf("[!!!!!error!!!!!]More than 1 devices of interest found. Disconnect unwanted devices\n");
        return 0;
    }

    usb_dev = cyusb_gethandle(0);
    if ( cyusb_getvendor(usb_dev) != 0x04b4 ) {
        printf("[!!!!!error!!!!!]Cypress chipset not detected\n");
        cyusb_close();
        return 0;
    }
	if (cyusb_claim_interface(usb_dev,0)){
		printf("claim usb interface fail.\n");	
		return 0;
	}
    printf("init_dev success.\n");
    return 1;
}


int parse_frame(unsigned char *src,unsigned char *dst){
    int ret = 1;
    if (check_sh(src)){
        src += 44;//sizeof(sh)=44
        while (bytes != image_size){
            if (check_lineh(src)){
                src += 8;//sizeof(lineh)=8
#if 0
                for (int i = 0; i < 1920;i++){
                        *buff++=*src++;
                        *buff++=*src++;
                        *buff++=*src++;
                        src++;
                }
#endif
                memcpy(dst,src,1920*4);
                src+=1920*4;
                dst+=1920*4;
            }else{
                ret=0;
                break;
            }
        }
    }else{
        ret=0;
        printf("frame header not found.\n");
    }

    return ret;
}


int xfer_frame(int *flag, unsigned char *buff){
    int transferred=0;
    static unsigned char _buff[(1920+8)*4*1080+44+512];
    unsigned int bytes=0;
	/*with short packet 4(dummy end)*/
    const int xfers=(1920*4+8)*1080+44 + 4;
    int ret;
	timeval tv1;
	timeval tv2;
	long usec;
    while(*flag){
        ret = cyusb_bulk_transfer(usb_dev, 0x81, _buff+bytes, 49152, &transferred, 0);
        bytes+=transferred;
        if (transferred==0){
            //printf("zero packet.\n");
			printf("bytes:%d,xfers:%d\n",bytes,xfers);
			if (bytes==xfers){	
				gettimeofday(&tv1,NULL);
                                parse_frame(_buff,buff);
				gettimeofday(&tv2,NULL);
				usec=(tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec);
				printf("xf ms:%f,us=%d\n",usec/1000.0,usec);
			}else{
				printf("zero packet,but xfer size not correct,drop.\n");
			}
            bytes=0;
	    	return 1;
        }
    }
    return 0;
}

