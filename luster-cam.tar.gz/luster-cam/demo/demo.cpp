#include <iostream>
#include "cam_reg.h"
#include "sys/time.h"
#include "unistd.h"

using namespace std;

int  main(int argc,  char* argv[]){
	//usb dev init
	int ret = init_usb_dev();
	if (!ret) {
		cout<<"init usb device fail.\n";
        return -1;
    }

	cout<<"configuration camera......\n";
	//set camera param
	ret=camera_reg_cmd(GREEN_GAIN_REG,GAIN_VAL);
    if (!ret){
       cout<<"set camera param fail.\n";
		exit(-1);
    }

	cout<<"start camera streamer.\n";
    ret=camera_start_streamer();
	//camera_stop();
	if (!ret){
		cout<<"start streamer fail.\n";
		exit(-1);
	}

	int my_flag = 1;
    static unsigned char buff[1080*1920*3];

	//time test 20170414
	long long start, end;
	timeval tv1;
	timeval tv2;
	long usec;

	int interval = 3;
	int ccount = 1;

	cout<<"going to main loop.\n";
	while (1) {
 		if (xfer_frame(&my_flag, buff)){
				gettimeofday(&tv2,NULL);
				usec=(tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec);
				tv1=tv2;
				printf("ms:%f,us=%d\n",usec/1000.0,usec);
		    	cout<<"xfer success.\n";
        	}else{
				cout<<"xfer fail.\n";
			}
	}
	return 0;
}
