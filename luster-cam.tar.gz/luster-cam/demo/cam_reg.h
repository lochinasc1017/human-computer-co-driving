#ifndef CAM_REG_H__
#define CAM_REG_H__

//set camera single frame 
#define OUT_MODE_SINFRM_REG	0x01
#define OUT_MODE_SINFRM		0x01

//set camera expo mode
#define EXPO_MODE_REG 		0x03
#define EXPO_MODE_AUTO 		0x00
#define EXPO_MODE_TRIGAUTO	0x01
#define EXPO_MODE_MANUAL 	0x02
#define EXPO_MODE_HOSTCTRL 	0x03

//set camera integral time
#define INTEGRAL_TIME_REG	0x06
#define INTEGRAL_TIME_VAL 	0x0001    //0x0001~0x0418

//set camera gain 
#define RED_BLUE_GAIN_REG	0x0A				
#define GREEN_GAIN_REG		0x0B
#define GAIN_VAL		0x03FF    //0x0001~0x03FF,default:0x0080

#define camera_ctl_cmd(addr,v) __camera_control(0x54,addr,v)
#define camera_reg_cmd(addr,v) __camera_control(0x55,addr,v)

#define camera_start_streamer() camera_ctl_cmd(0x02,0x01)

int init_usb_dev();
int usb_fork_thread();

void resume_usb_thread();
void suspend_usb_thread();
void kill_usb_thread();

int camera_stop();

int __camera_control(unsigned char sign,unsigned short addr,unsigned int value);

int xfer_frame(int *flag, unsigned char *buff);

#endif
