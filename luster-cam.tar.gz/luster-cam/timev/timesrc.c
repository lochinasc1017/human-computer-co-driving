#include <stdlib.h>
#include <stdio.h>
#include <sys/time.h>

int main(){
	struct timeval v;
	gettimeofday(&v,NULL);
	while(1){	
		//system("clear");
		gettimeofday(&v,NULL);
		printf("%06d", v.tv_usec);
		printf("\b\b\b\b\b\b");
	}
}
