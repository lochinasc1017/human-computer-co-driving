#ifndef IMAGEVIEWER_H
#define IMAGEVIEWER_H

#include <QMainWindow>
#include <QSharedMemory>
#include <QImage>
#include <QThread>
#include <QTime>
#include "worker.h"

QT_BEGIN_NAMESPACE
class QAction;
class QLabel;
class QMenu;
class QScrollArea;
class QScrollBar;
class QToolBar;
class QLinkedList<QImage*>;

QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow();
    void setFB(FrameBuff *bf){
        m_framebuff=bf;
    }
    bool InitWorker(FrameBuff *buff);
private slots:
    void StreamerAct();
    void about();

private:
    void updateActions();
    //void setImage(const QImage &newImage);
    void ShowNetImage(quint8 *buff);

    void BuildToolBar();
private:
    QThread workerThread;

    void StartWork(QString f){
        emit operate(f);
    }

    void StopJob(){
        m_Worker->StopJob();
    }
public slots:
      void NewFrameReady(quint8 *buff);
signals:
      void operate(const QString &);

      void NewStreamer();
private:
      Worker *m_Worker;
      FrameBuff *m_framebuff;
private:
    QLabel *m_frameNrLabel;
    QLabel *m_frameTimeLabel;
    QLabel *m_frameTimeLabel2;
    QLabel *m_ImageLabel;
    QToolBar *m_ToolBar;

    QAction *streamerAct;
    QAction *suspendAct;
};

#endif
