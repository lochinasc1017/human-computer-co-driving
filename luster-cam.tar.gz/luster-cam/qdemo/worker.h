#ifndef WORK_H
#define WORK_H

#include <QThread>
#include <QDebug>
#include "cyusb.h"
#include "framebuff.h"
#include <unistd.h>

//set camera single frame
#define OUT_MODE_SINFRM_REG	0x01
#define OUT_MODE_SINFRM		0x01

//set camera expo mode
#define EXPO_MODE_REG 		0x03
#define EXPO_MODE_AUTO 		0x00
#define EXPO_MODE_TRIGAUTO	0x01
#define EXPO_MODE_MANUAL 	0x02
#define EXPO_MODE_HOSTCTRL 	0x03

//set camera integral time
#define INTEGRAL_TIME_REG	0x06
#define INTEGRAL_TIME_VAL 	0x0001    //0x0001~0x0418

//set camera gain
#define RED_BLUE_GAIN_REG	0x0A
#define GREEN_GAIN_REG		0x0B
#define GAIN_VAL		0x03FF    //0x0001~0x03FF,default:0x0080

class Worker : public QObject{
      Q_OBJECT
public:
    Worker();
    bool Init();
    void setFB(FrameBuff *bf){
        m_frameBuff=bf;
    }

public:
    struct frame_info_struct{
        quint8 note[128];
        quint32 x_res;
        quint32 y_res;
        quint32 frame;
        quint32 size_lenght;//每行数据量，最小单位word
        quint16 bit;
        quint16 ret;
    };//36Bytes

public:/*interface*/
    void DoStreamer();
    void SuspendJob();
    void StopJob();

    inline bool IsStop(){
       return m_RunFlag==EStopped;
    }
    inline bool isRunning(){
       return m_RunFlag==ERunning;
    }

    int camera_25fames() {
        __camera_control(0x55,0xfff4,0xc814044c);
        usleep(10000);
        __camera_control(0x55,0xfff4,0xc8160a8c);
        usleep(10000);
        __camera_control(0x55,0xfff4,0xcaf428bf);
        usleep(10000);
        __camera_control(0x55,0xf0,0xff);
        usleep(10000);
    }

    inline int camera_start_streamer() {
        return __camera_control(0x54,0x02,0x01);
    }
    inline int camera_stop_streamer(){
        return __camera_control(0x54,0x02,0x00);
    }

signals:
    void NewFrameReady(quint8 *buff);
private:
    void __sv_first_packet(void *buff){
        FILE *file;
        file=fopen("000.raw", "wb+");
        if (!file){
            return ;
        }
        fwrite(buff, 1920*1080*4, 1, file);
        fclose(file);
    }

    enum RunStatus{
        EStopped=0,
        ERunning=2,
    };

    bool init_usb_dev();
    cyusb_handle *m_dev;
    FrameBuff *m_frameBuff;
    volatile quint32 m_RunFlag;
    int parse_frame(unsigned char *src, unsigned char *dst);
    int __camera_control(unsigned char sign,unsigned short addr,unsigned int value);
};

#endif // WORK_H
