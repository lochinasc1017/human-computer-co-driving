#include "worker.h"
#include <QDebug>
#include <QThread>
#include <QTime>
#include <QColor>
#include <QString>

#include <QFile>
#include <QTextStream>


static inline bool check_sh(void *sh){
    unsigned int *temp = (unsigned int*)sh;
    if (temp[0] == 0x7c7c7c7c && temp[1] == 0x01010101){
        return true;
    }else{
        qDebug()<<hex<<temp[0]<<"  "<<hex<<temp[1];
        return false;
    }
}

static inline bool check_lineh(void *lineh){
    unsigned int *temp = (unsigned int*)lineh;
    if (temp[0] == 0x7c7c7c7c && temp[1] == 0x02020202){
        return true;
    }
    else{
        return false;
    }
}

Worker::Worker(){
    m_frameBuff=NULL;
}

bool Worker::init_usb_dev(){
    int r;

    r = cyusb_open();
    if ( r < 0 ) {
       qDebug()<<"[!!!!!error!!!!!]Error opening library";
       return false;
    }
    else if ( r == 0 ) {
        qDebug()<<"[!!!!!error!!!!!]No device found";
        return false;
    }
    if ( r > 1 ) {
        qDebug()<<"[!!!!!error!!!!!]More than 1 devices of interest found. Disconnect unwanted devices";
        return false;
    }

    m_dev = cyusb_gethandle(0);
    if ( cyusb_getvendor(m_dev) != 0x04b4 ) {
        qDebug()<<"[!!!!!error!!!!!]Cypress chipset not detected";
        cyusb_close();
        return false;
    }
#if 0
    if (!cyusb_claim_interface(m_dev,0)){
        qDebug()<<"[error]claim device fail.";
        return false;
    }
#endif
    qDebug()<<"worker:init_dev success.";
    return true;
}


bool Worker::Init(){
    m_RunFlag=EStopped;
    if (!init_usb_dev()){
        qDebug()<<"[!!!!!error!!!!!]init device fail.";
    }else{
        qDebug()<<"init device success.";
    }
    return true;
}

/*********************************************************************
sign:0x54,0x55
*********************************************************************/
int Worker::__camera_control(unsigned char sign,unsigned short addr,unsigned int v){
    unsigned char cmd[10]={0xaa,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xff};
    cmd[1]=sign;
    cmd[2]=addr>>8;
    cmd[3]=addr&0xff;
    cmd[4]=v>>24;
    cmd[5]=(v>>16)&0xff;
    cmd[6]=(v>>8)&0xff;
    cmd[7]=v&0xff;
    int ret=cyusb_control_transfer(m_dev,0x20,0xE0,0,0x00,cmd,10,1000);
    if (ret!=10){
        qDebug()<<"[error]__camera_control,ret="<<ret<<".\n";
    }
    return ret==10?1:0;
}

void Worker::StopJob(){
    camera_stop_streamer();
    m_RunFlag=EStopped;
}

void Worker::DoStreamer(){
    m_RunFlag=ERunning;
    camera_25fames();
    if (!camera_start_streamer()){
        qDebug()<<"send command fail.";
        return;
    }
    if(!m_dev){
        qDebug()<<("NO USB device!\n");
        return;
    }else{
        qDebug()<<"worker::Streamer().";
    }
    static int frame_counter=0;
    frame_counter=0;
    int transferred=0;
    quint8 _buff[(1920+8)*4*1080+44+512];
    qint32 bytes=0;
    const int xfers=(1920*4+8)*1080+44+4;
    struct timeval tv;
    struct timeval tv1, tv2;
gettimeofday(&tv1,NULL);
    int count= 0;
    while(m_RunFlag && m_dev){
        cyusb_bulk_transfer(m_dev, 0x81, _buff+bytes, 49152, &transferred, 0);
        bytes+=transferred;
        //printf("count = %d\n", count);
        if (transferred==0){
            count++;
            if(count == 300) {
                count=0;
                gettimeofday(&tv2,NULL);
                qDebug()<<"ms="<<((tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec))/1000<<"\n";
                tv1 = tv2;
            }
            bytes=0;
        }
    }
    return;

}

int Worker::parse_frame(unsigned char *src,unsigned char *dst){
    int ret = 1;
    if (check_sh(src)){
        src += 44;//sizeof(sh)=44
        for (int i = 0; i < 1080;i++){
            if (check_lineh(src)){
                src += 8;/*skip line header*/
                memcpy(dst,src,1920*4);
                src+=1920*4;
                dst+=1920*4;

#if 0
                for (int j = 0; j < 1920;j++){
                    *dst++=*src++;
                    *dst++=*src++;
                    *dst++=*src++;
                    src++;
                }
#endif
            }else{
                qDebug()<<("check lineh\n");
                ret=0;
                break;
            }
        }
    }else{
        ret=0;
        qDebug()<<("frame header not found.\n");
    }
    qDebug()<<("okkk");
    return ret;
}

