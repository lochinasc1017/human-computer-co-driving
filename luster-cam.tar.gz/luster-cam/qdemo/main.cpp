#include <QApplication>
#include <QCommandLineParser>

#include "MainWindow.h"
#include "framebuff.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QGuiApplication::setApplicationDisplayName(MainWindow::tr("camviewer_luster"));
    QCommandLineParser commandLineParser;
    commandLineParser.addHelpOption();
    commandLineParser.addPositionalArgument(MainWindow::tr("[file]"), MainWindow::tr("Image file to open."));
    commandLineParser.process(QCoreApplication::arguments());

    FrameBuff *buff=new FrameBuff();
    buff->create();
    qDebug()<<"create frame buff.";
    MainWindow imageViewer;
    imageViewer.InitWorker(buff);
    imageViewer.show();
    return app.exec();
}
