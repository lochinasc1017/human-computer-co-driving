#ifndef FRAMEBUFF_H
#define FRAMEBUFF_H

class FrameBuff
{
public:
    FrameBuff();
    bool create();
public:

    quint8 *getbuff();
    void putbuff(quint8 *buff);

    inline bool IsValid(quint8 *buff){
        return buff>m_mem;
    }

private:

    quint8 *m_mem;
    quint32 *m_ptr;
};

#endif // SHAREDFRAMEBUFF_H
