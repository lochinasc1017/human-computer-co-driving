#include <QtWidgets>
#include <QMessageBox>
#include <qdebug.h>
#include <QDockWidget>
#include <sys/time.h>
#include "MainWindow.h"

MainWindow::MainWindow()
   : m_ImageLabel(new QLabel)
{

    m_ImageLabel->setBackgroundRole(QPalette::Base);
    m_ImageLabel->setSizePolicy(QSizePolicy::Ignored, QSizePolicy::Ignored);
    m_ImageLabel->setScaledContents(true);

    setCentralWidget(m_ImageLabel);

    BuildToolBar();
    m_frameNrLabel=new QLabel();
    m_frameTimeLabel=new QLabel();
    m_frameTimeLabel2=new QLabel();
    m_frameNrLabel->setFixedWidth(60);
    statusBar()->addWidget(new QLabel(tr("    frameNo:")));
    statusBar()->addWidget(m_frameNrLabel);
    statusBar()->addWidget(new QLabel(tr("    time:")));
    statusBar()->addWidget(m_frameTimeLabel);
    statusBar()->addWidget(new QLabel(tr("    time2:")));
    statusBar()->addWidget(m_frameTimeLabel2);



    resize(QGuiApplication::primaryScreen()->availableSize() * 4 / 5);
}

bool MainWindow::InitWorker(FrameBuff *buff){
    m_framebuff=buff;
    m_Worker = new Worker;
    m_Worker->setFB(buff);
    if (!m_Worker->Init()){
        return false;
    }

    m_Worker->moveToThread(&workerThread);

    connect(&workerThread, &QThread::finished, m_Worker, &QObject::deleteLater);
    connect(this, &MainWindow::NewStreamer, m_Worker, &Worker::DoStreamer);
    connect(m_Worker,&Worker::NewFrameReady,this,&MainWindow::NewFrameReady);

    workerThread.start();
    return true;
}

void MainWindow::NewFrameReady(quint8 *buff){
    ShowNetImage(buff);
    m_framebuff->putbuff(buff);
}

void MainWindow::ShowNetImage(quint8 *buff){
    struct timeval tv1,tv2;
    float usec;
    gettimeofday(&tv1,NULL);
    m_frameNrLabel->setText(QString::number(*((unsigned int*)buff)));
    QString tvstr=QString("%1").arg(tv1.tv_usec);
    m_frameTimeLabel->setText(tvstr);
    m_frameTimeLabel2->setText(QString::number(*((unsigned int*)(buff+4))));


    QImage *img=new QImage(buff,1920,1080,QImage::Format_RGB32);
    m_ImageLabel->setPixmap(QPixmap::fromImage(*img));
    gettimeofday(&tv2,NULL);
    usec=(tv2.tv_sec-tv1.tv_sec)*1000000+(tv2.tv_usec-tv1.tv_usec);
    qDebug()<<"show:ms="<<usec/1000<<" us="<<usec;
    delete img;
}

void MainWindow::StreamerAct(){
    if(m_Worker->IsStop()){
        qDebug()<<"worker running";
        QPixmap pixmap2(":/rsc/img/img-stop");
        streamerAct->setIcon(pixmap2);
        streamerAct->setToolTip("停止");
        emit NewStreamer();
    }else{
        qDebug()<<"worker stoped";
        m_Worker->StopJob();
        QPixmap pixmap1(":/rsc/img/img-streamer");
        streamerAct->setIcon(pixmap1);
        streamerAct->setToolTip("开始");
    }
}

void MainWindow::about(){
    QMessageBox::about(this, tr("About viewer"),
            tr("viewer is a usb-viewer tool."));
}

void MainWindow::BuildToolBar(){

    streamerAct=new QAction(QIcon(":/rsc/img/img-streamer"),tr("streamer"), 0);
    streamerAct->setToolTip("开始");


    connect(streamerAct,SIGNAL(triggered()),this,SLOT(StreamerAct()));

    m_ToolBar=addToolBar(tr("img_tool"));
    m_ToolBar->addSeparator();
    m_ToolBar->addAction(streamerAct);
}


