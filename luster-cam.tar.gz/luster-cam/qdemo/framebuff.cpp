#include <QDebug>
#include "framebuff.h"

#define line_sz (1920*4)
#define frame_sz (line_sz*1080)

FrameBuff::FrameBuff(){
    m_mem=0;
}

bool FrameBuff::create(){
    m_mem=(quint8*)malloc(frame_sz*4+4*sizeof(quint32));
    m_ptr=(quint32*)(m_mem+frame_sz*4);
    if (!m_mem){
        qDebug()<<"alloc frame buffer fail."<<endl;
        return false;
    }
    return true;
}

quint8 *FrameBuff::getbuff(){
    for (int i = 0; i < 4;i++){
        if (m_ptr[i]!=0x0c0c0c0c){
            m_ptr[i]=0x0c0c0c0c;
            return m_mem+i*frame_sz;
        }
    }
    qDebug()<<"getbuff fail";
    return NULL;
}

void FrameBuff::putbuff(quint8 *buff){
    if (buff){
        m_ptr[(buff-m_mem)/frame_sz]=0;
    }
}

